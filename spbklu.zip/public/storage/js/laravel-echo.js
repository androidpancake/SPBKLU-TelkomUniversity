import Echo from 'laravel-echo';

import Pusher from 'pusher-js';

window.Pusher = Pusher;

const echoInstance = new Echo({
    broadcaster: 'pusher',
    key: '27ac5f4676ab40d1f6a0',
    cluster: 'ap1',
    forceTLS: true
});

// var channel = Echo.channel('booking-monitor');
// channel.listen('.booking-monitor', function(data) {
//   alert(JSON.stringify(data));
// });

echoInstance.channel('booking-monitor')
    .listen('BookingCodeProcessed', (e) => {
        console.log("event accepted", e);
        displayTransactionData(e.transactionData);
    });
