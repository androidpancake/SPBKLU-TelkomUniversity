@extends('layouts.template')
@section('content')

@section('breadcrumb')
@include('template.breadcrumb')

<div class="">

</div>
@endsection