
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>

<div class="h-full bg-white">
    <div class="flex flex-col justify-center items-center space-y-2">
        <h1>Transaksi gagal</h1>
        <p>Maaf transaksi anda gagal</p>
        <a href="#" class="bg-green-600 px-4 py-2.5 text-white rounded-full w-full text-center">Kembali</a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/transaction/fail.blade.php ENDPATH**/ ?>