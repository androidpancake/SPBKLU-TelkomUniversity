
<?php $__env->startSection('content'); ?>

<div class="flex flex-col p-2 h-full overflow-y-auto">
    <h1 class="font-semibold text-center"><?php echo e($terms['content']); ?></h1>
    <p><?php echo e($terms['title']); ?></p>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/terms/terms.blade.php ENDPATH**/ ?>