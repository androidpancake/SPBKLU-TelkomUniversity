
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<div class="w-full">
    <img src="<?php echo e(asset('storage/image/checkout.png')); ?>" class="w-full" alt="">
</div>
<form action="<?php echo e(route('transaction.success', $id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="flex flex-col h-full justify-between space-y-2 p-2">
        <div class="space-y-1">
            <p class="text-center">Booking Code : <?php echo e($transactionData['bookingCode']); ?></p>
            <div class="w-full bg-white rounded-lg border-2 flex justify-between p-2">
                <div>
                    <p class="text-sm text-gray-600">Nama pembeli</p>
                    <p class="font-semibold text-base"><?php echo e($username); ?></p>
                </div>
                <div class="flex flex-col justify-end">
                    <p class="text-sm text-gray-600">Station</p>
                    <p class="font-semibold text-base"><?php echo e($transactionData['station']); ?></p>
                </div>
            </div>
            <div class="w-full bg-white rounded-lg border-2 flex justify-between items-center p-2 ">
                <div>
                    <p>Slot</p>
                </div>
                <div>
                    <p class="font-semibold text-base"><?php echo e($transactionData['slot']); ?></p>
                </div>
            </div>
            <div class="w-full bg-white rounded-lg border-2 flex justify-between items-center p-2">
                <div>
                    <p>Total</p>
                </div>
                <div>
                    <p class="font-semibold text-base">Rp.<?php echo e($transactionData['price']); ?>,00</p>
                </div>
            </div>
            <?php if($transactionData['status'] != 'SUCCESS' && $transactionData['status'] != 'DONE'): ?>
            <div class="w-full bg-blue-200 rounded-lg items-center p-2">
                <h1 class="font-medium text-sm">Information</h1>
                <p class="text-xs">Segera lakukan pembayaran atau transaksi akan dibatalkan otomatis</p>
            </div>
        </div>
        <div>
            <button type="submit" class="px-2 py-2.5 w-full bg-green-600 rounded-lg text-white font-medium">Bayar</button>
        </div>
        <?php endif; ?>
    </div>
    
</form>

<?php if($transactionData['status'] =! 'SUCCESS'): ?>
<form action="<?php echo e(route('transaction.cancel', $id)); ?>" method="POST" class="p-2 text-center">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="bg-transparent text-red-400">Batalkan transaksi</button>
</form>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/transaction/detail.blade.php ENDPATH**/ ?>