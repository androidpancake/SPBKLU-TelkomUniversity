<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Verify Your Email Address</div>

                <div class="card-body">
                  <?php if(session('resent')): ?>
                      <div class="alert alert-success" role="alert">
                          <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                      </div>
                  <?php endif; ?>
                  <?php if(Session::has('error')): ?>
                    <p class=" pb-3 alert <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
                  <?php endif; ?>

                    Before proceeding, please check your email for a verification link.
                    If you did not receive the email

                        <form class="d-inline" method="POST" action="App\Http\Controllers\Auth\ResetController@verify">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-link p-0 m-0 align-baseline" style="text-decoration:none;"><?php echo e(__('click here to request another')); ?></button>.
                        </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\laravel-with-firebase-auth\resources\views/reset/email.blade.php ENDPATH**/ ?>