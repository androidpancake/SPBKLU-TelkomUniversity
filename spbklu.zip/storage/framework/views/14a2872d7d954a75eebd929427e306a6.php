
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>

<?php $__env->stopSection(); ?>

<div class="bg-white flex flex-col space-y-4 items-center justify-between h-full p-2">
    <div></div>
    <div class="space-y-2">
        <h1 class="text-center text-2xl font-semibold">Transaksi gagal</h1>
        <p class="text-sm text-center">Maaf transaksi anda error</p>
    </div>
    <div class="flex flex-col w-full space-y-2">
        <a href="<?php echo e(route('station.index')); ?>" class="bg-gray-300 text-gray-800 px-3 py-2.5 w-full rounded-lg text-center">Ke halaman utama</a> 
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/transaction/midtrans/error.blade.php ENDPATH**/ ?>