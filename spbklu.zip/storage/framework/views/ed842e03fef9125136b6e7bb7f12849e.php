
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<div class="flex flex-col bg-gray-50 h-screen">
    <img src="<?php echo e(asset('storage/image/bg-telu.png')); ?>" class="h-auto" alt="">
    <div class="flex flex-col space-y-2 w-full p-3">
        <div class="bg-white p-2 rounded border-2 flex justify-center">
            <div class="inline-flex">
                <p>status :</p>
                <p class="font-semibold">Diambil</p>
            </div>
        </div>
        <div class="flex flex-col bg-white border-2 rounded p-4 h-full">
            <h1 class="font-bold text-center text-lg">Tata cara pengambilan</h1>
            <ul class="list-disc list-inside">
                <ol class="mt-2 space-y-1 list-decimal list-inside">
                    <li>Tekan tombol pada pintu cabin yang kosong</li>
                    <li class="whitespace-normal">Masukan baterai yang akan ditukar pada 
                        <p class="font-medium">Slot 1 atau slot 2</p>
                        lalu tutup kembali pintu kabin</li>
                    <li>Tekan tombol pada pintu cabin yang terdapat baterai siap pakai.</li>
                    <li>Tutup kembali pintu kabin</li>
                </ol>
            </ul>
            <div class="relative w-full py-2">
                <div class="absolute inset-0 z-10 mb-1 w-full rounded-md px-3 py-2 text-white">
                    <img src="<?php echo e(asset('storage/image/anime-title.png')); ?>" alt="">  
                </div>
                <div class="absolute inset-x-0 z-auto mb-1 mt-24 rounded-md px-3 py-2 text-white">
                    <img src="<?php echo e(asset('storage/image/bg.png')); ?>" class="w-full" alt="">
                </div>
            </div>
        </div>
    </div>
    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/booking/guide.blade.php ENDPATH**/ ?>