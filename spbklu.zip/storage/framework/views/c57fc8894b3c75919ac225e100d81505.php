
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<div class="bg-gray-100 p-2 h-full">
    <form action="<?php echo e(route('booking.guide1', $id)); ?>" method="POST" class="flex flex-col justify-between h-full">
        <?php echo csrf_field(); ?>
        <div class="bg-white border border-gray-300 rounded w-full px-3 py-2 space-y-3">
            <div class="space-y-3">
                <h1 class="text-center font-bold">Status pemesanan</h1>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500">Nama</p>
                    <p class="font-semibold"><?php echo e($user->displayName); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500">Stasiun</p>
                    <p class="font-semibold"><?php echo e($bookingData['station']); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500">Slot</p>
                    <p class="font-semibold"><?php echo e($bookingData['slot']); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500 nowrap">Tanggal transaksi</p>
                    <p class="font-semibold"><?php echo e($bookingData['transaction_time']); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500">Status pembayaran</p>
                    <p class="font-semibold"><?php echo e($bookingData['status']); ?></p>
                </div>
                <div class="flex justify-between">
                    <p class="text-base text-gray-500">Kode booking</p>
                    <p class="font-semibold"><?php echo e($bookingData['bookingCode']); ?></p>
                </div>
            </div>
        </div>
        <div>
            <button type="submit" class="bg-green-500 px-2 py-2.5 rounded font-semibold text-center w-full text-white">Confirm</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/booking/detail.blade.php ENDPATH**/ ?>