<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="flex flex-row justify-center">
        <div class="">
            <div class="bg-white rounded">
                <div class="text-gray-900 text-base font-semibold">Verify Your Email Address</div>

                <div class="bg-white">
                  <?php if(session('resent')): ?>
                      <!-- <div class="alert alert-success" role="alert">
                          <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                      </div> -->
                      <div class="p-4 mb-4 text-sm text-blue-800 rounded-lg bg-blue-50 dark:bg-gray-800 dark:text-red-400" role="alert">
                            <span class="font-medium"><?php echo e(__('A fresh verification link has been sent to your email address.')); ?></span>
                        </div>
                  <?php endif; ?>
                  <?php if(Session::has('error')): ?>
                    <p class="bg-red-100 p-3 <?php echo e(Session::get('alert-class', 'alert-danger')); ?>"><?php echo e(Session::get('error')); ?></p>
                  <?php endif; ?>

                    Before proceeding, please check your email for a verification link.
                    If you did not receive the email

                    <form class="inline-flex" method="POST" action="<?php echo e(route('reset.verify')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="bg-blue py-2.5 px-2"><?php echo e(__('click here to request another')); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/reset/email.blade.php ENDPATH**/ ?>