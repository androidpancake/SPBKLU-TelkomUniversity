
<?php $__env->startSection('content'); ?>

<?php $__env->startSection('breadcrumb'); ?>
<?php echo $__env->make('layouts.breadcrumb', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<div class="flex flex-col space-y-2 overflow-y-auto h-full p-2">
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $station): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('station.detail', $data)); ?>" class="block">
        <div class="rounded-lg bg-white shadow border border-gray-200">
            <img src="<?php echo e($station['image']); ?>" class="rounded-t-lg" alt="">
            <div class="flex flex-row justify-between items-center w-full px-2 py-2.5">
                <div class="w-full">
                    <p class="text-gray-500 text-sm">station</p>
                    <h1 class="font-semibold text-lg flex-nowrap"><?php echo e($station['name']); ?></h1>
                    <!-- <div>
                        <p class="text-sm text-gray-500">Ketersediaan</p>
                    </div> -->
                    <div class="inline-flex items-center space-x-2">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5 text-gray-800" fill="currentColor" viewBox="0 0 256 256"><path d="M200,40H56A16,16,0,0,0,40,56V200a16,16,0,0,0,16,16H200a16,16,0,0,0,16-16V56A16,16,0,0,0,200,40Zm0,80H136V56h64ZM120,56v64H56V56ZM56,136h64v64H56Zm144,64H136V136h64v64Z"></path></svg>
                        <p class="text-sm font-semibold"><?php echo e($slotCount); ?> dari <?php echo e($slotTotal); ?> slot</p>
                    </div>
                </div>
                <a href="<?php echo e($station['direction']); ?>">
                    <div class="inline-flex space-x-2 rounded-full p-2 border">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4 text-green-500" fill="currentColor" viewBox="0 0 256 256"><path d="M232.49,112.49l-48,48a12,12,0,0,1-17-17L195,116H128a84.09,84.09,0,0,0-84,84,12,12,0,0,1-24,0A108.12,108.12,0,0,1,128,92h67L167.51,64.48a12,12,0,0,1,17-17l48,48A12,12,0,0,1,232.49,112.49Z"></path></svg>                    
                    </div>
                </a>
            </div>
        </div>
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/list/index.blade.php ENDPATH**/ ?>