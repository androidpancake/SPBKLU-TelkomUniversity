<?php $__env->startSection('content'); ?>
  

  <?php if(Session::has('message')): ?>
    <div class="alert alert-info alert-dismissible fade show m-3" role="alert">
      <strong><?php echo e(Session::get('message')); ?></strong>
      <button type="button" class="close" data-dismiss="alert" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
  <?php endif; ?>

  <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="alert alert-danger alert-dismissible fade show m-3" role="alert">
        <strong><?php echo e($error); ?></strong>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>

  <div class="container">
    <div class="row">
      
      <div class="col-lg-6">
        <div class="card shadow rounded">
          <div class="card-body">
            <h3 class="text-primary">Upload Image</h3><br>
            <?php echo Form::open(['action' => 'App\Http\Controllers\ImageController@store', 'method' => 'POST' , 'files'=>true]); ?>


            <div class="form-group">
              <?php echo Form::label('image', 'Uplode Picture'); ?>

              <br>
              <?php echo Form::file('image', null,['class'=>'form-control']); ?>

            </div>

            <div class="form-group">
              <?php echo Form::submit('Upload', ['class'=>'btn btn-primary']); ?>

            </div>

            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
      <div class="col-lg-6 pt-lg-0 pt-3">
        <div class="card shadow rounded">
          <div class="card-body">
            <h3 class="text-primary">Image fetched from Firebase Storage.</h3>
            <img src="<?php echo e($image); ?>" class="img-fluid" alt="Responsive image">
            <br>
            <a href="<?php echo e($image); ?>">Link generated from Firebase</a>
            <?php echo Form::open(['method'=>'DELETE', 'action'=> ['App\Http\Controllers\ImageController@destroy',"delete"]]); ?>

            <div class="form-group pt-2">
              <?php echo Form::submit('Delete Image', ['class'=>'btn btn-danger']); ?>

            </div>
            <?php echo Form::close(); ?>

          </div>
        </div>
      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/img.blade.php ENDPATH**/ ?>