
<?php $__env->startSection('content'); ?>
<?php if($message('error')): ?>
    <span><?php echo e($message('error')); ?></span>
<?php endif; ?>
<h1>Maaf terjadi kesalahan</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECT\project-signa\spbklu\resources\views/booking/empty.blade.php ENDPATH**/ ?>